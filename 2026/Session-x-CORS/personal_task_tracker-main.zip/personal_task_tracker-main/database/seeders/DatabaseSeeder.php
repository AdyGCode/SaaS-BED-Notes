<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\Priority;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

final class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
                RolesPermissionsSeeder::class,UserSeeder::class, StatusSeeder::class, PrioritySeeder::class,
        ]
        );
    }
}

<?php

namespace Database\Seeders;

use App\Models\Status;
use Illuminate\Database\Seeder;

class StatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $statuses = [
            [
                'id' => 1,
                'title' => 'Incomplete',
            ],
            [
                'id' => 2,
                'title' => 'Failed',
            ],
            [
                'id' => 3,
                'title' => 'Complete',
            ],
        ];

        foreach ($statuses as $status) {

            $statusEntry = Status::create(
                [
                    'id' => $status['id'],
                    'title' => $status['title'],
                ]);
        }
    }
}

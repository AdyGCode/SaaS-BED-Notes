<?php

declare(strict_types=1);

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

final class RolesPermissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        $seedPermissions = [
            'task-browse',
            'task-read',
            'task-edit', 'task-own-edit',
            'task-add',
            'task-delete', 'task-own-delete',

            'category-browse',
            'category-read',
            'category-edit',
            'category-add',
            'category-delete',
        ];

        foreach ($seedPermissions as $newPermission) {
            Permission::create(['name' => $newPermission, 'guard_name' => 'sanctum']);
        }

        $client = [
            'task-browse', 'task-read', 'task-own-edit', 'task-add', 'task-own-delete',

            'category-browse', 'category-read',
        ];
        $roleClient = Role::firstOrCreate(['name' => 'client', 'guard_name' => 'sanctum']);
        $roleClient->syncPermissions(Permission::whereIn('name', $client)->get());

        $staff = [
            'task-browse', 'task-read', 'task-edit', 'task-add', 'task-delete',

            'category-browse', 'category-read',
        ];
        $roleStaff = Role::firstOrCreate(['name' => 'staff', 'guard_name' => 'sanctum']);
        $roleStaff->syncPermissions(Permission::whereIn('name', $staff)->get());

        $admin = [
            'task-browse', 'task-read', 'task-edit', 'task-add', 'task-delete',

            'category-browse', 'category-read', 'category-edit', 'category-add', 'category-delete',
        ];
        $roleAdmin = Role::firstOrCreate(['name' => 'admin', 'guard_name' => 'sanctum']);
        $roleAdmin->syncPermissions(Permission::whereIn('name', $admin)->get());
    }
}

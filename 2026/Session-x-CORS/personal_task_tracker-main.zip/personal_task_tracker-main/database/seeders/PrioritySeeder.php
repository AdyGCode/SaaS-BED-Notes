<?php

namespace Database\Seeders;

use App\Models\Priority;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PrioritySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $priorities = [
            [
                'id' => 1,
                'title' => 'Low',
            ],
            [
                'id' => 2,
                'title' => 'Medium',
            ],
            [
                'id' => 3,
                'title' => 'High',
            ],
            [
                'id' => 4,
                'title' => 'ASAP',
            ],
        ];

        foreach ($priorities as $priority) {

            $priorityEntry = Priority::create(
                [
                    'id' => $priority['id'],
                    'title' => $priority['title'],
                ]);
        }
    }
}

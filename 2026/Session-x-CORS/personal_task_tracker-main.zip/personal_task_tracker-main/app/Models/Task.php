<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class Task extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'owner_id',
        'category_id',
        'title',
        'notes',
        'priority',
        'due_date',
        'status',
    ];

    public function category(): BelongsTo
    {
        return $this->BelongsTo(Category::class, 'category_id');
    }

    public function status(): BelongsTo
    {
        return $this->BelongsTo(Status::class, 'status');
    }

    public function priority(): BelongsTo
    {
        return $this->BelongsTo(Priority::class, 'priority');
    }

    public function owner(): BelongsTo
    {
        return $this->belongsTo(User::class, 'owner_id');
    }
}

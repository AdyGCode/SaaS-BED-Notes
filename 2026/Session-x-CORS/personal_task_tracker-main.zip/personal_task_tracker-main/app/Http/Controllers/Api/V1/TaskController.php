<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\V1\StoreTaskRequest;
use App\Http\Requests\Api\V1\UpdateTaskRequest;
use App\Http\Resources\TaskResource;
use App\Models\Task;

final class TaskController extends Controller
{
    /**
     * Display a listing of the Tasks.
     */
    public function index()
    {
        if (auth()->user()->hasPermissionTo('task-browse')) {
            $tasks = Task::All();

            return TaskResource::collection($tasks);
        }

        return response()->json(['message' => 'Action Unauthorized'], 403);

    }

    /**
     * Store a newly created Task in storage.
     *
     * @property TaskResource $resource
     */
    public function store(StoreTaskRequest $request)
    {
        if (auth()->user()->hasPermissionTo('task-add')) {
            $validated = $request->validated();
            $validated['owner_id'] = auth()->id();
            $task = Task::create($validated);

            return response()->json(new TaskResource($task), 201);
        }

        return response()->json(['message' => 'Action Unauthorized'], 403);

    }

    /**
     * Display the specified Task.
     */
    public function show(Task $task)
    {
        if (auth()->user()->hasPermissionTo('task-read')) {
            return response()->json(new TaskResource($task));
        }

        return response()->json(['message' => 'Action Unauthorized'], 403);

    }

    /**
     * Update the specified Task in storage.
     */
    public function update(UpdateTaskRequest $request, Task $task)
    {
        if (auth()->user()->hasPermissionTo('task-edit') or
            (auth()->user()->hasPermissionTo('task-own-edit') and auth()->user()->id === $task->owner_id)) {
            $validated = $request->validated();
            $task->update($validated);

            return response()->json(new TaskResource($task));
        }

        return response()->json(['message' => 'Action Unauthorized'], 403);

    }

    /**
     * Remove the specified Task from storage.
     */
    public function destroy(Task $task)
    {
        if (auth()->user()->hasPermissionTo('task-delete') or
            (auth()->user()->hasPermissionTo('task-own-delete') and auth()->user()->id === $task->owner_id)) {
            $task->delete();

            return response()->json(['message' => 'Success']);
        }

        return response()->json(['message' => 'Action Unauthorized'], 403);

    }
}

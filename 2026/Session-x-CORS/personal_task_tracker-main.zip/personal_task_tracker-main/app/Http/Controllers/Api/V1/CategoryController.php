<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\V1\StoreCategoryRequest;
use App\Http\Requests\Api\V1\UpdateCategoryRequest;
use App\Http\Resources\CategoryResource;
use App\Models\Category;

final class CategoryController extends Controller
{
    /**
     * Display a listing of the Categories.
     */
    public function index()
    {
        if(auth()->user()->hasPermissionTo('category-browse')) {
            $category = Category::All();

            return CategoryResource::collection($category);
        }

        return response()->json(['message' => 'Action Unauthorized'], 403);
    }

    /**
     * Store a newly created Category in storage.
     */
    public function store(StoreCategoryRequest $request)
    {
        if(auth()->user()->hasPermissionTo('category-add')) {
            $validated = $request->validated();
            $category = Category::create($validated);

            return response()->json(new CategoryResource($category), 201);
        }

        return response()->json(['message' => 'Action Unauthorized'], 403);
    }

    /**
     * Display the specified Category.
     */
    public function show(Category $category)
    {
        if(auth()->user()->hasPermissionTo('category-read')) {
            return response()->json(new CategoryResource($category));
        }

        return response()->json(['message' => 'Action Unauthorized'], 403);
    }

    /**
     * Update the specified Category in storage.
     */
    public function update(UpdateCategoryRequest $request, Category $category)
    {
        if(auth()->user()->hasPermissionTo('category-edit')) {
            $validated = $request->validated();
            $category->update($validated);

            return response()->json(new CategoryResource($category));
        }

        return response()->json(['message' => 'Action Unauthorized'], 403);
    }

    /**
     * Remove the specified Category from storage.
     */
    public function destroy(Category $category)
    {
        if(auth()->user()->hasPermissionTo('category-delete')) {
            $category->delete();
            return response()->json(['Message' => 'Success']);
        }

        return response()->json(['message' => 'Action Unauthorized'], 403);
    }
}

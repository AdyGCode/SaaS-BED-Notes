<?php

use App\Models\Category;
use App\Models\User;
use App\Models\Task;
use Database\Seeders\PrioritySeeder;
use Database\Seeders\RolesPermissionsSeeder;
use Database\Seeders\StatusSeeder;
use Database\Seeders\UserSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

beforeEach(function () {
    # Seed test database
    $this->seed(RolesPermissionsSeeder::class);
    $this->seed(StatusSeeder::class);
    $this->seed(PrioritySeeder::class);

    # Create Admin User
    $user = User::factory()->raw();
    $this->user = User::create($user);
    $token = $this->user->createToken('token')->plainTextToken;
    $this->token = $token;

    $this->user->assignRole('admin');

    # Create Client User
    $user = User::factory()->raw();
    $this->client = User::create($user);
    $token = $this->client->createToken('client-token')->plainTextToken;
    $this->client_token = $token;

    $this->client->assignRole('client');

    # Create Example Categorys
    $attributes = [
        'title' => 'Example',
        'description' => 'Example',
    ];
    $attributesTwo = [
        'title' => 'Example 2',
        'description' => 'Example 2',
    ];

    Category::create($attributes);
    Category::create($attributesTwo);

    # Create Example Tasks
    $attributes = [
        'owner_id' => 1,
        'category_id' => 1,
        'title' => 'task 1',
        'notes' => 'task 1',
        'priority' => 1,
        'due_date' => '2027-1-1',
        'status' => 1,
    ];
    $attributesTwo = [
        'owner_id' => 2,
        'category_id' => 2,
        'title' => 'task 2',
        'notes' => 'task 2',
        'priority' => 4,
        'due_date' => '1993-1-1',
        'status' => 2,
    ];

    Task::create($attributes);
    Task::create($attributesTwo);
});


# Endpoint Success
it('Create a new task', function () {
    $attributes = [
        'category_id' => 1,
        'title' => 'task',
        'notes' => 'task',
        'priority' => 4,
        'due_date' => date('Y-m-d', strtotime('1995-01-01')),
        'status' => 2,
    ];
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->postJson('api/v1/tasks', $attributes);
    $response->assertStatus(201)->assertJson(
        [
            'owner_id' => $this->user->id,
            'category_id' => 1,
            'title' => 'task',
            'notes' => 'task',
            'priority' => 4,
            'due_date' => '1995-01-01',
            'status' => 2,],
    );
    $this->assertDatabaseHas('tasks', $attributes);
});

it('Display Task', function () {
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->getJson('api/v1/tasks/1');
    $response->assertStatus(200);
    $response->assertJsonStructure(
        [
            'id',
            'owner_id',
            'category_id',
            'title',
            'notes',
            'priority',
            'due_date',
            'status',
        ]
    );
});

it('Display all Tasks', function () {
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->getJson('api/v1/tasks');
    $response->assertStatus(200);
    $response->assertJsonStructure([
        'data' => [
            [
                'id',
                'owner_id',
                'category_id',
                'title',
                'notes',
                'priority',
                'due_date',
                'status',
            ]
        ]
    ]);
});

it('Update Task', function () {
    $attributes = [
        'category_id' => 2,
        'title' => 'update task',
        'notes' => 'update task',
        'priority' => 3,
        'due_date' => date('Y-m-d', strtotime('2029-01-01')),
        'status' => 1,
    ];
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->putJson('api/v1/tasks/1', $attributes);
    $response->assertStatus(200)->assertJson(
        [
            'id' => 1,
            'owner_id' => $this->user->id,
            'category_id' => 2,
            'title' => 'update task',
            'notes' => 'update task',
            'priority' => 3,
            'due_date' => date('Y-m-d', strtotime('2029-01-01')),
            'status' => 1,
        ]
    );
    $this->assertDatabaseHas('tasks', $attributes);
});

it('Patch Task', function () {
    $attributes = [
        'due_date' => date('Y-m-d', strtotime('2029-01-01')),
    ];
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->putJson('api/v1/tasks/1', $attributes);
    $response->assertStatus(200)->assertJson(
        [
            'id' => 1,
            'owner_id' => $this->user->id,
            'category_id' => 1,
            'title' => 'task 1',
            'notes' => 'task 1',
            'priority' => 1,
            'due_date' => date('Y-m-d', strtotime('2029-01-01')),
            'status' => 1,
        ]
    );
    $this->assertDatabaseHas('tasks', [
        'id' => 1,
        'owner_id' => $this->user->id,
        'category_id' => 1,
        'title' => 'task 1',
        'notes' => 'task 1',
        'priority' => 1,
        'due_date' => date('Y-m-d', strtotime('2029-01-01')),
        'status' => 1,
    ]);
});

it('Delete Task', function () {
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->deleteJson('api/v1/tasks/1');
    $response->assertStatus(200)->assertJson([
        'message' => 'Success',
    ]);
    $this->assertDatabaseMissing('tasks', [
        'owner_id' => 1,
        'category_id' => 1,
        'title' => 'task 1',
        'notes' => 'task 1',
        'priority' => 1,
        'due_date' => '2027-1-1',
        'status' => 1,
    ]);
});

it('Attempt Delete own task as client', function () {
    $response = $this->withHeader('Authorization', 'Bearer '.$this->client_token)->deleteJson('api/v1/tasks/2');
    $response->assertStatus(200);
    $response->assertJsonStructure([
        'message',
    ]);
    $this->assertDatabaseMissing('tasks', [
        'owner_id' => 2,
        'category_id' => 2,
        'title' => 'task 2',
        'notes' => 'task 2',
        'priority' => 4,
        'due_date' => '1993-1-1',
        'status' => 2,
    ]);
});

it('Attempt Delete others task as client', function () {
    $response = $this->withHeader('Authorization', 'Bearer '.$this->client_token)->deleteJson('api/v1/tasks/1');
    $response->assertStatus(403);
    $response->assertJson([
        'message' => 'Action Unauthorized',
    ]);
});

# Unauthenticated 401
it('Call Endpoint without Token', function () {
    $response = $this->getJson('api/v1/tasks');
    $response->assertStatus(401)->assertJson([
        'message' => 'Unauthenticated.',
    ]);
});

# Action Unauthorized 403
it('Call Endpoint without permissions', function () {
    $client = User::factory()->raw();
    $clientUser = User::create($client);

    $clientToken = $clientUser->createToken('no-permissions')->plainTextToken;

    $response = $this->withHeader('Authorization', 'Bearer '.$clientToken)->deleteJson('api/v1/tasks/1');
    $response->assertStatus(403)->assertJson([
        'message' => 'Action Unauthorized',
    ]);
});

# Invalid Values 422
it('Store Task with invalid values', function () {
    $attributes = [
        'title' => 0,
    ];
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->postJson('api/v1/tasks', $attributes);
    $response->assertStatus(422)->assertJsonStructure(
        [
            'message',
            'errors' => [
                '*' => [],
            ]
        ],
    );
});

it('Update Task with invalid values', function () {
    $attributes = [
        'category_id' => 20,
    ];
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->putJson('api/v1/tasks/1', $attributes);
    $response->assertStatus(422)->assertJsonStructure(
        [
            'message',
            'errors' => [
                '*' => [],
            ]
        ],
    );
});

# Not found 404
it('Display non existent Task', function () {
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->getJson('api/v1/tasks/8');
    $response->assertStatus(404);
    $response->assertJsonStructure([
            'message',
        ]);
});

it('Delete non existent Task', function () {
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->deleteJson('api/v1/tasks/8');
    $response->assertStatus(404);
    $response->assertJsonStructure([
            'message',
        ]);
});

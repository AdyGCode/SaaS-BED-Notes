<?php

use App\Models\Category;
use App\Models\User;
use Database\Seeders\PrioritySeeder;
use Database\Seeders\RolesPermissionsSeeder;
use Database\Seeders\StatusSeeder;
use Database\Seeders\UserSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

beforeEach(function () {
    # Seed test database
    $this->seed(RolesPermissionsSeeder::class,UserSeeder::class, StatusSeeder::class, PrioritySeeder::class);

    # Create Test User
    $user = User::factory()->raw();
    $this->user = User::create($user);

    $token = $this->user->createToken('token')->plainTextToken;
    $this->token = $token;

    $this->user->assignRole('admin');

    # Create Example Categorys
    $attributes = [
        'title' => 'Example',
        'description' => 'Example',
    ];
    $attributesTwo = [
        'title' => 'Example 2',
        'description' => 'Example 2',
    ];

    Category::create($attributes);
    Category::create($attributesTwo);
});


# Endpoint Success
it('Create a new category', function () {
    $attributes = [
        'title' => 'test',
        'description' => 'test',
    ];
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->postJson('api/v1/categories', $attributes);
    $response->assertStatus(201)->assertJsonStructure(
        ['id','title','description'],
    );
    $this->assertDatabaseHas('categories', $attributes);
});

it('Display Category', function () {
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->getJson('api/v1/categories/1');
    $response->assertStatus(200);
    $response->assertJsonStructure(
        ['id','title','description']
    );
});

it('Display all Categories', function () {
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->getJson('api/v1/categories');
    $response->assertStatus(200);
    $response->assertJsonStructure([
        'data' => [
            [
            'id',
            'title',
            'description',
            ]
        ]
    ]);
});

it('Update Category', function () {
    $attributes = [
        'title' => 'test',
        'description' => 'test',
    ];
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->putJson('api/v1/categories/1', $attributes);
    $response->assertStatus(200)->assertJsonStructure(
        ['id','title','description'],
    );
    $this->assertDatabaseHas('categories', $attributes);
});

it('Patch Category', function () {
    $attributes = [
        'description' => 'test',
    ];
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->putJson('api/v1/categories/1', $attributes);
    $response->assertStatus(200)->assertJsonStructure(
        ['id','title','description'],
    );
    $this->assertDatabaseHas('categories', [
        'title' => 'Example',
        'description' => 'test',
    ]);
});

it('Delete Category', function () {
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->deleteJson('api/v1/categories/1');
    $response->assertStatus(200)->assertJson([
        'Message' => 'Success',
    ]);
    $this->assertDatabaseMissing('categories', [
        'title' => 'Example',
        'description' => 'Example',
    ]);
});


# Endpoint Fail

# Unauthenticated 401
it('Call Endpoint without Token', function () {
    $response = $this->getJson('api/v1/categories');
    $response->assertStatus(401)->assertJson([
        'message' => 'Unauthenticated.',
    ]);
});

# Action Unauthorized 403
it('Call Endpoint without permissions', function () {
    $client = User::factory()->raw();
    $clientUser = User::create($client);

    $clientToken = $clientUser->createToken('no-permissions')->plainTextToken;

    $response = $this->withHeader('Authorization', 'Bearer '.$clientToken)->deleteJson('api/v1/categories/1');
    $response->assertStatus(403)->assertJson([
        'message' => 'Action Unauthorized',
    ]);
});

# Invalid Values 422
it('Store Category with invalid values', function () {
    $attributes = [
        'title' => 0,
    ];
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->postJson('api/v1/categories', $attributes);
    $response->assertStatus(422)->assertJsonStructure(
        [
            'message',
            'errors' => [
                '*' => [],
            ]
        ],
    );
});

it('Update Category with invalid values', function () {
    $attributes = [
        'title' => 0,
        'description' => 0,
    ];
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->putJson('api/v1/categories/1', $attributes);
    $response->assertStatus(422)->assertJsonStructure(
        [
            'message',
            'errors' => [
                '*' => [],
            ]
        ],
    );
});

# Not found 404
it('Display non existent Category', function () {
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->getJson('api/v1/categories/8');
    $response->assertStatus(404);
    $response->assertJsonStructure([
            'message',
        ]);
});

it('Delete non existent Category', function () {
    $response = $this->withHeader('Authorization', 'Bearer '.$this->token)->deleteJson('api/v1/categories/8');
    $response->assertStatus(404);
    $response->assertJsonStructure([
            'message',
        ]);
});

# Semester Unit Plan

## Duration: 4 Weeks

### Week 1
- CORS Theory
- Stage 1 Lab

### Week 2
- Debugging techniques
- Stage 2 Lab

### Week 3
- Sanctum auth
- Stage 3 Lab

### Week 4
- Production Chaos Lab
- Assessment submission

## Assessment

Students must:
- Diagnose failures
- Fix configs
- Explain behaviour

## Rubric

| Criteria | Marks |
|---------|------|
| Diagnosis | 40 |
| Fix | 30 |
| Explanation | 30 |

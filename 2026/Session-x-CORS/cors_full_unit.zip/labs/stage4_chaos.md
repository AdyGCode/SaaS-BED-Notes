---
theme: default
title: Stage 4 – Production Chaos
---

# Chaos Lab

## Issues Injected
- HTTPS frontend vs HTTP API
- Wrong cookie domain
- Secure flag missing
- Proxy strips headers

---

# Tasks

1. Fix protocol mismatch
2. Fix cookies
3. Fix proxy headers
4. Verify auth

---

# End

# Instructor Notes

## Delivery Plan

- Week 1: Basics + Stage 1
- Week 2: Debugging
- Week 3: Sanctum
- Week 4: Chaos Lab + Assessment

## Assessment

Students submit:
- Root cause report
- Fixed config
- Explanation of preflight

## Marking (example)
- Diagnosis: 40%
- Fix correctness: 30%
- Explanation: 30%

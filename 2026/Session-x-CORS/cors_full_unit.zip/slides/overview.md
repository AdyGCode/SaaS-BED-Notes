---
theme: default
title: CORS + Laravel Full Unit
---

# CORS + Laravel Unit

## Outcomes
- Explain browser CORS model
- Configure Laravel correctly
- Debug multi-bug failures
- Implement Sanctum auth
- Diagnose production issues

---

# Learning Path

```mermaid
graph LR
Basics --> Debugging --> Auth --> Chaos
```

---

# Key Idea

CORS is enforced by the browser.

---

# End

# Full Teaching Module Repo

## Run

docker-compose up --build

## Purpose

Simulates separate frontend + API servers for CORS labs.

Extend API folder with a full Laravel app if required.

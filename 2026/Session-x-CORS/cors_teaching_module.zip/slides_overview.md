---
theme: default
---

# CORS Full Teaching Module

## Sections
- Concepts
- Labs
- Debugging
- Auth with Sanctum
- Production patterns

---

# Learning Path

1. Basic CORS
2. Debugging
3. Auth
4. Chaos Lab

---

# Key Idea

CORS = browser security rule

---

# End

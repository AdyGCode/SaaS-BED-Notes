# CORS + Laravel Teaching Module

## Contents
- Slides (concept + lab)
- Hands-on labs (3 stages + advanced)
- Docker multi-host setup
- Instructor notes
- Assessment guidance

## Labs
1. Basic CORS (Laravel)
2. Multi-bug debugging
3. Sanctum authentication
4. Production chaos (advanced)

## Run
Use Slidev for slides:

npm install
npx slidev

Run Docker labs:

docker-compose up --build

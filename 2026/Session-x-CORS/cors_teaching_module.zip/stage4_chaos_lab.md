---
theme: default
---

# Stage 4: Production Chaos Lab

## Scenario

- HTTPS frontend
- HTTP API
- Sanctum auth
- Reverse proxy misconfig

---

# Bugs Introduced

- Mixed protocol (HTTP/HTTPS)
- Wrong cookie domain
- Missing secure cookie flag
- Proxy not forwarding headers

---

# Tasks

1. Identify all failures
2. Fix HTTPS mismatch
3. Fix cookie config
4. Fix proxy

---

# Learning Outcome

Students can debug real production issues

---

# Instructor Notes

## Teaching Strategy

### Stage 1
Explain basic CORS behavior

### Stage 2
Force debugging mindset

### Stage 3
Introduce authentication complexity

### Stage 4
Simulate production issues

## Key Questions
- Where does request originate?
- What headers are present?
- What does browser block?

## Assessment
Students must:
- Diagnose
- Explain
- Fix

## Common Errors
- Misunderstanding origin
- Ignoring preflight
- Confusing auth failure
